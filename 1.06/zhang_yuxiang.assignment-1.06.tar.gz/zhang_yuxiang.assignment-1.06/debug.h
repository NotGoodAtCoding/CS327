#ifndef DEBUG_H
#define DEBUG_H

extern int debug;

int debug_log(const char *, ...);

int debug_reset();

#endif
