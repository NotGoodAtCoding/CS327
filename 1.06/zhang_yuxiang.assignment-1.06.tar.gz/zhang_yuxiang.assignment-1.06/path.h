#ifndef PATH_H
#define PATH_H

#include "room.h"

/* pave a path from an unconnected room to a connected room */
void path_pave(Room*, Room*);

#endif
