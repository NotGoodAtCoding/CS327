#ifndef UI_H
#define UI_H

int ui_clearRow(int row);

int ui_printDungeon();

int ui_mList();

#endif
